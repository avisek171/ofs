<?php 
//echo 'ofs';exit;
session_start(); //start session
session_destroy();
?>

<?php
session_start(); //start temp session until logout/browser closed
include("connection/connect.php");  //include connection file
error_reporting(E_ALL);  // using to hide undefine undex errors
//site Settings
$sqls="select status from site_settings where sn='2'";
$querys=mysqli_query($db,$sqls);													
$WPSettings=mysqli_fetch_assoc($querys);
//echo '<pre>';print_r($WPSettings); echo '</pre>';

if(empty($_SESSION["user_id"])){
	$_SESSION["user_id"] = abs( crc32( uniqid('DB-') ) ); // put user id into temp session
}

if(isset($_POST['submit2'])){  
	if($_POST['res_name'] === '0' ) {  
		$error = "Station Name Not Selected !";		
	}else{ 
		$_SESSION["station"] = $_POST['res_name'];
		header('Location: restaurants');  
	}
}  

if(isset($_POST['submit3'])){  
	$ress= mysqli_query($db,"select pnr from call_back where pnr='".$_POST['pnr']."'");
	
	$sqldate="SELECT DATE_ADD(NOW(), INTERVAL 750 MINUTE) AS DT";
	$querydate=mysqli_query($db,$sqldate);
	$rowsdate=mysqli_fetch_array($querydate);
		
	$ipAddrClient = getenv('HTTP_CLIENT_IP')?:
	getenv('HTTP_X_FORWARDED_FOR')?:
	getenv('HTTP_X_FORWARDED')?:
	getenv('HTTP_FORWARDED_FOR')?:
	getenv('HTTP_FORWARDED')?:
	getenv('REMOTE_ADDR');
	
	if(mysqli_num_rows($ress) > 0 ) {
		echo '<script>alert("we already received your request. You will receive a Call Back Soon.")</script>';
		//echo '<h5 class="pnr-error"><center> !!</center></h5>';
		header("refresh:5;url=https://dibrail.com/");
	}
	else{
		$_SESSION["cus_pnr"] = $_POST['pnr'];
		$_SESSION["cus_phone"] = $_POST['mobile'];
		
		if(preg_match('/^[0-9]{10}+$/', $_POST['mobile']) && preg_match('/^[0-9]{10}+$/', $_POST['pnr'])) {
			echo $mql = "INSERT INTO call_back (mobile,pnr,logtime,status,custom_ipaddr) VALUES('".$_POST['mobile']."','".$_POST['pnr']."','".$rowsdate['DT']."','Unread','".$ipAddrClient."')";
			//mysqli_query($db, $mql);
			
			if(mysqli_query($db, $mql)){
				//echo  '<script>alert("Ordered successfully")</script>';  
				header("refresh:0;url=cb_confirm"); // redireted onc
			} 
			$success = "Request Sent successfully! <p>You will be receive a callback soon .</p>'";
			
		} else {
			echo "Invalid Phone Number or PNR";
		}
		
	}

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Google Tag Manager -->
	<meta name="google-site-verification" content="k4BS4Kwtbf3oJEA8X0TbtgBUlKbl_meA4L2fWG-rX3k" />
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-P4NWD6Q');</script>
	<!-- End Google Tag Manager -->
	<title>Online Food Order in Train | E-Catering Services - DIBRAIL</title>
	<meta name="description" content="Get Hot & Delicious Food on Train at the Best Price, we deliver food at your Seat. Dibrail is a top e-Catering Service for Food on Train in India. Call 8263-940-940">  
	
    <meta name="keywords" content="online food in train, rail food, meals on train, book food in train, train food delivery,train food, order food on train, order food online in train, train food order,food on train, food in train, food delivery in train, food order in train, order food in train, online food order in train, online food at train, meals on wheels india" />	 
    <link rel="icon" type="image/x-icon"  href="img/favicon.ico">   
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	 <script  src="js/jquery.min.js"></script>
    <link href="css/style.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Oswald&display=swap" rel="stylesheet">

	<style>
	.ui-autocomplete {
	  position: absolute;
	  cursor:pointer; 
	  max-height:210px; 
	  overflow-y:scroll;
	  top: 100%;
	  left: 0;
	  z-index: 1000;
	  display: none;
	  float: left;
	  max-width: 260px;
	  padding: 5px 0;
	  margin: 2px 0 0;
	  list-style: none;
	  font-size: 14px;
	  text-align: left;
	  background-color: #ffffff;
	  border: 1px solid #cccccc;
	  border: 1px solid rgba(0, 0, 0, 0.15);
	  border-radius: 4px;
	  -webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
	  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
	  background-clip: padding-box;
	}

	.ui-autocomplete > li > div {
	  display: block;
	  padding: 3px 20px;
	  clear: both;
	  font-weight: normal;
	  line-height: 1.42857143;
	  color: #333333;
	  white-space: nowrap;
	}

	.ui-state-hover,
	.ui-state-active,
	.ui-state-focus {
	  text-decoration: none;
	  color: #262626;
	  background-color: #f5f5f5;
	  cursor: pointer;
	} 

	.ui-helper-hidden-accessible {
	  border: 0;
	  clip: rect(0 0 0 0);
	  height: 1px;
	  margin: -1px;
	  overflow: hidden;
	  padding: 0;
	  position: absolute;
	  width: 1px;

	@media all and (transform-3d), (-webkit-transform-3d) {
	  .carousel-inner > .item.next,
	  .carousel-inner > .item.active.right {
		left: 0;
		-webkit-transform: translate3d(-100%, 0, 0);
		transform: translate3d(-100%, 0, 0);
	  }
	  .carousel-inner > .item.prev,
	  .carousel-inner > .item.active.left {
		left: 0;
		-webkit-transform: translate3d(100%, 0, 0);
		transform: translate3d(100%, 0, 0);
	  }
	}

	</style>
	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-P4NWD6Q');</script>
	<!-- End Google Tag Manager -->
</head>

<body >


<!-- partial:index.partial.html -->
<header class="sticky">
  <div class="new-menu-toggle"><i class="fa fa-bars"></i></div>
  <div class="logo"><a href="https://www.dibrail.com/"> <img style="padding-bottom: 2px;" src="img/dibrail-logo.webp" alt="dibrail" height="35"> </a></div>
  <nav>
    <ul>
		<li class="nav-item"> <a class="nav-link" href="https://dibrail.com/"><span class=" show-mob"><i aria-hidden="true" class="fa fa-home"></i> </span>Home </a> </li>
		<li class="nav-item"> <a class="nav-link" href="track_order" ><span class=" show-mob"><i aria-hidden="true" class="fa fa-map-marker"></i> </span> Track Order</a> </li>
		<li class="nav-item"> <a class="nav-link" href="group-order" ><span class=" show-mob"><i aria-hidden="true" class="fa fa-users"></i> </span> Group Order</a> </li>
		<li class="nav-item show-mob"> <a class="nav-link" href="cancel"><span class=" show-mob"><i aria-hidden="true" class="fa fa-times-circle-o"></i> </span> Cancel Order</a> </li>
		<li class="nav-item show-mob"><a class="nav-link" href="cb"><span class=" show-mob"><i aria-hidden="true" class="fa fa-phone"></i> </span> Call Back Req.</a> </li>
		<li class="nav-item show-mob"> <a class="nav-link" href="offers"><span class=" show-mob"><i aria-hidden="true" class="fa fa-gift"></i> </span> Offers/Coupons</a> </li>
		<li class="nav-item show-mob"> <a class="nav-link" href="feedback"><span class=" show-mob"><i aria-hidden="true" class="fa fa-list"></i> </span> Feedback</a> </li> 
		<li class="nav-item show-mob"> <a class="nav-link" href="faq"><span class=" show-mob"><i aria-hidden="true" class="fa fa-question-circle"></i> </span> FAQ Questions</a> </li>
		<li class="nav-item"> <a class="nav-link" href="jain-food-in-train"><span class=" show-mob"><i aria-hidden="true" class="fa fa-cutlery"></i> </span> Jain Food</a> </li>
		<li class="nav-item show-mob"> <a class="nav-link" href="veg-food-in-train"><span class=" show-mob"><i aria-hidden="true" class="fa fa-leaf"></i> </span> Pure Veg Food In Train</a> </li>
		<li class="nav-item show-mob"> <a class="nav-link" href="non-veg-food-in-train"><span class=" show-mob"><i aria-hidden="true" class="fa fa-cutlery"></i> </span> Non Veg Food In Train</a> </li>
		<li class="nav-item show-mob"> <a class="nav-link" href="food-delivery-in-train"><span class=" show-mob"><i aria-hidden="true" class="fa fa-train"></i> </span> Food Delivery In Train</a> </li>
		<li class="nav-item">
		  <a href="tel:8263940940" >
			  <button  class="btn btn-md" style="background: #FD6624;color:#fff;border-radius:24px;"><i class="fa fa-phone" style="padding:0"></i>&nbsp;&nbsp; <b>8263-940-940</b> </button>
		  </a>
		</li>
    </ul>
  </nav>
  
  <div class="new-menu-phone"><a href="tel:8263940940" style="background:gray;padding:5px 10px;color:white;border-radius:20px;"><i class="fa fa-phone"></i></a></div>
  
</header>
<!-- partial -->	
	
<div class="col-md-12" style="text-align:center;margin-top:80px">
	<div class="col-md-7">
		<div class="text-inner" >
			<h1 class="header-font" id="station-form" style="font-family:'Oswald';">Order <span style="color:#7AA741">Food</span> In Train</h1>
			<p style="margin-bottom:0px">Order Spicy & Delicious Food In Train From FSSAI Approved Restaurants.</p>
			<div class="show-mob-inverse">
			
				<a  href="tel:8263940940" ><img src="img/cbb.webp" alt="call 8263940940"  class="click-call"></a>
				<h5  style="font-family:'Oswald';color:#035F8D" >OR</h5>
			</div>
			<!-- partial:index.partial.html -->
			<div class="row"  style="padding:0px;">
				
				<div class="col-xs-12 col-sm-12 col-md-6 img-gap">
					<div class="login-form" >
						
						<p style="color:#fff;padding-top:15px;font-size:18px"><b>Enter Delivery Station</b></p>
						<form class="form-inline container" style="padding-bottom:15px"  action="" method="post">
							<div class="group">
								<input  type="text" id="res_name" name="res_name" style="width:100%" required class="input" placeholder="Search by Station Name">
							</div>
							
							<div class="group" >
								<input type="submit" name="submit2" class="button" value="Order Now">
							</div>
							<div class="hr"></div>
						</form>
						
					</div>
					
				</div>
				<h5 class="show-mob" style="font-family:'Oswald';color:#035F8D;line-height:5px;" >OR</h5>
				<div class="col-xs-12 col-sm-12 col-md-6 img-gap">
					<div class="login-form" >
						<p style="color:#fff;padding-top:15px;font-size:18px"><b>Order by PNR</b></p>
						<form class="form-inline container"  action="" method="post">
						<div class="group">
							<input type="text" id="stationText" pattern="[0-9][0-9]{9}" name="pnr" required style="width:100%" minlength="10" maxlength="10" class="input" placeholder="Enter 10-digit PNR No.">
						</div>
						<div class="group">
							<input type="text" pattern="[6789][0-9]{9}" name="mobile" required style="width:100%" required minlength="10" maxlength="10" class="input" placeholder="Enter 10-digit Mobile No.">
						</div>
						
						<div class="group">
							
							<input type="submit" name="submit3" class="button" value="Order Now">
						</div>
						</form>
						
						
					</div>
					
				</div>
				
			</div>
			<!-- partial -->
			
		</div>
		
	</div>
	<div class="col-md-5 my-2">
		<div style="float:center">
		  <div style="text-align:center">
			<div >
			  <img class="img-fluid rounded-3 mb-2" width="70%" src="img/thali_veg.png" alt="First slide">
			  <h4>Veg-Thali</h4>
			</div>
		  </div>
		</div>
	</div>
</div>



<div class="section-food">
	<div class="row" style="margin:0">
		<!-- Popular block starts -->
		<div class="popular col-md-12" style="padding:2rem 0 ">
			<div class="get-food-steps col-xs-12 col-sm-12 col-md-12 col-lg-12" style="background:#ddd;border-radius:20px">
				<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 white-txt col" style="margin:0px">
					<div class="step step-1" >
					<h2 class="how-it-works-wrap-header"><b>Get your Favourite food in Train<br>Just Follow These Steps :-</b> </h2>
					
					<h6 style="padding-left:18px;font-weight:500;" class="how-it-works-wrap-hidden">Order Spicy & Delicious food in Train from FSSAI approved restaurants across 450+ Station in India</h6>

					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 " style="margin:0px;padding:0">
					<ul class="pay-info" style="font-size:16px;">
						<li>
							<div class="how-it-works-wrap col-xs-3">
								<div style="text-align:center">
									<img  src="img/train.webp"  alt="Dibrail" class="get-food-steps-img" />
									<p class="get-food-steps-text"><B>Enter PNR</B></p>
								</div>
							</div>
						</li>
						<li>
							<div class="how-it-works-wrap col-xs-3">
								<div style="text-align:center">
									<img  src="img/menu.webp"  alt="Dibrail" class="get-food-steps-img" />
									<p class="get-food-steps-text"><B>Select Food</B></p>
								</div>
							</div>
						</li>
						<li>
							<div class="how-it-works-wrap col-xs-3">
								<div style="text-align:center">
									<img  src="img/wallet.webp"  alt="Dibrail" class="get-food-steps-img" />
									<p class="get-food-steps-text"><B>Pay Online / COD</B></p>
								</div>
							</div>
						</li>
						<li>
							<div class="how-it-works-wrap col-xs-3">
								<div style="text-align:center">
									<img  src="img/passenger.webp"  alt="Dibrail" class="get-food-steps-img" />
									<p class="get-food-steps-text"><B>Get Food</B></p>
								</div>
							</div>
						</li>
						
						
						
					</ul>

				</div>
			</div>
			
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 m-t-20">
				<div class="title text-xs-center m-b-30 m-t-20">
					<h4 style="text-decoration: underline; text-underline-offset: 4px;">Popular Dishes of the Month</h4>
					<p class="lead">Get your favourite food</p>
				</div>
				<div class="row dish-category">
					<div class="col-xs-6 col-sm-6 col-md-2 food-item">
						<div class="food-item-wrap">
							<div class="figure-wrap bg-image" style="background:url('img/dishes/paraths.jpeg') center center / cover no-repeat;" >
								<div class="distance"><i class="fa fa-pin"></i>Trending</div>
							</div>
							<div class="content" style="padding:15px">
								<h6 class="mb-1">Aloo Paratha</h6>
								<button class="btn theme-btn w-100" onclick="focusFunction()">Order Now</button>
								
							</div>							
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-2 food-item">
						<div class="food-item-wrap">
							<div class="figure-wrap bg-image" style="background:url('img/dishes/biryanis.jpeg') center center / cover no-repeat;" >
								
							</div>
							<div class="content" style="padding:15px">
								<h6 class="mb-1">Chicken Biryani</h6>
								<button class="btn theme-btn w-100" onclick="focusFunction()">Order Now</button>
							</div>							
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-2 food-item">
						<div class="food-item-wrap">
							<div class="figure-wrap bg-image" style="background:url('img/dishes/search-pizza.webp') center center / cover no-repeat;" >
								<div class="distance"><i class="fa fa-pin"></i>Customisable</div>
							</div>
							<div class="content" style="padding:15px">
								<h6 class="mb-1">Pizza</h6>
								<button class="btn theme-btn w-100" onclick="focusFunction()">Order Now</button>
							</div>							
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-2 food-item">
						<div class="food-item-wrap">
							<div class="figure-wrap bg-image" style="background:url('img/dishes/biryani.webp') center center / cover no-repeat;" >
								
							</div>
							<div class="content" style="padding:15px">
								<h6 class="mb-1">Biryanis</h6>
								<button class="btn theme-btn w-100" onclick="focusFunction()">Order Now</button>
							</div>							
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-2 food-item">
						<div class="food-item-wrap">
							<div class="figure-wrap bg-image" style="background:url('img/dishes/thali-3.jpeg') center center / cover no-repeat;" >
								
							</div>
							<div class="content" style="padding:15px">
								<h6 class="mb-1">South-Thali</h6>
								<button class="btn theme-btn w-100" onclick="focusFunction()">Order Now</button>
							</div>							
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-2 food-item">
						<div class="food-item-wrap">
							<div class="figure-wrap bg-image" style="background:url('img/dishes/sandwich.webp') center center / cover no-repeat;" >
								<div class="distance"><i class="fa fa-pin"></i>Hot</div>
							</div>
							<div class="content" style="padding:15px">
								<h6 class="mb-1">Sandwiches</h6>
								<button class="btn theme-btn w-100" onclick="focusFunction()">Order Now</button>
							</div>							
						</div>
					</div>
					
				</div>
			</div>
		</div>
	
	</div>
</div>




<!-- How it works block starts -->

<!-- How it works block starts -->
<div class="how-it-works" style="padding-bottom:0px;" id="why-choose-us-hide">
	<div class="containe">
		<div class="text-xs-center" >
			<h2 style="text-decoration: underline; text-underline-offset: 4px;color:#fff;">Why Choose Us ?</h2>
			<h5 style="color: beige;line-height: 1.5;">Dibrail delivers food from its FSSAI approved Restaurant Partners across multiple Stations all over India.<br> We offer the widest range of Cuisines such as  Veg Food, Non-Veg Food, Jain Food,<br> North Indian, South Indian, Gujarati Foods, Marwari Food, Chinese Food, etc. You can order a Multiple Food menu without any extra charges from <b>www.dibrail.com </b>or direct Call us at <u style="color:lightsteelblue"> <a href="tel:+918260940940">08263-940-940</a></u> .</h5>
			<!-- 3 block sections starts -->
			<div class="row how-it-works-solution">
				<div class="col-xs-12 col-sm-12 col-md-6 how-it-works-steps white-txt col">
					<div class="how-it-works-wrap">
						<div  style="padding-bottom:30px">
							<div class="containe ">
								<img width="100%"  src="img/dishes/dibrail-pizz.webp" alt="Dibrail" class="dark-log" style="width:85%;" />
							</div>
						</div>
					</div>
				</div>
				
				<div class="col-xs-12 col-sm-12 col-md-6 how-it-works-steps white-txt col">
					<div class="how-it-works-wrap">
						<div class="step step-1" >
							<div class="icon" data-step="1">
								<svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 483 483" width="512" height="512">
									<g fill="#FFF">
										<path d="M467.006 177.92c-.055-1.573-.469-3.321-1.233-4.755L407.006 62.877V10.5c0-5.799-4.701-10.5-10.5-10.5h-310c-5.799 0-10.5 4.701-10.5 10.5v52.375L17.228 173.164a10.476 10.476 0 0 0-1.22 4.938h-.014V472.5c0 5.799 4.701 10.5 10.5 10.5h430.012c5.799 0 10.5-4.701 10.5-10.5V177.92zM282.379 76l18.007 91.602H182.583L200.445 76h81.934zm19.391 112.602c-4.964 29.003-30.096 51.143-60.281 51.143-30.173 0-55.295-22.139-60.258-51.143H301.77zm143.331 0c-4.96 29.003-30.075 51.143-60.237 51.143-30.185 0-55.317-22.139-60.281-51.143h120.518zm-123.314-21L303.78 76h86.423l48.81 91.602H321.787zM97.006 55V21h289v34h-289zm-4.198 21h86.243l-17.863 91.602h-117.2L92.808 76zm65.582 112.602c-5.028 28.475-30.113 50.19-60.229 50.19s-55.201-21.715-60.23-50.19H158.39zM300 462H183V306h117v156zm21 0V295.5c0-5.799-4.701-10.5-10.5-10.5h-138c-5.799 0-10.5 4.701-10.5 10.5V462H36.994V232.743a82.558 82.558 0 0 0 3.101 3.255c15.485 15.344 36.106 23.794 58.065 23.794s42.58-8.45 58.065-23.794a81.625 81.625 0 0 0 13.525-17.672c14.067 25.281 40.944 42.418 71.737 42.418 30.752 0 57.597-17.081 71.688-42.294 14.091 25.213 40.936 42.294 71.688 42.294 24.262 0 46.092-10.645 61.143-27.528V462H321z" />
										<path d="M202.494 386h22c5.799 0 10.5-4.701 10.5-10.5s-4.701-10.5-10.5-10.5h-22c-5.799 0-10.5 4.701-10.5 10.5s4.701 10.5 10.5 10.5z" /> </g>
								</svg>
							</div>
							<h2 style="color:#000;background:#fff;padding:18px;border-radius:5px;font-weight:700;">How to place online food order in train with Dibrail? </h2>
							<ul class="pay-info" style="font-size:16px;color: #fff;text-align:left;margin-left:15%;line-height:1.8"><br>
								<li><i class="fa fa-arrow-right" aria-hidden="true"></i> Visit the website www.dibrail.com </li>
								<li><i class="fa fa-arrow-right" aria-hidden="true"></i> Enter the name of the station where you want your food to be delivered </li>
								<li><i class="fa fa-arrow-right" aria-hidden="true"></i> Add the food items of your choice from the menu of a restaurant partner </li>
								<li><i class="fa fa-arrow-right" aria-hidden="true"></i> Enter the passenger details </li>
								<li><i class="fa fa-arrow-right" aria-hidden="true"></i> Make payment through any of the online modes or choose to pay Cash on Delivery </li>
								<li><i class="fa fa-arrow-right" aria-hidden="true"></i> Sit back and relax! Your order will be delivered to your train seat before the train’s departure </li>
								
								
							</ul>
						</div>
					</div>
				</div>
				
				
				
			</div>
			
			
			<div class="row how-it-works-solution">
				
				<div class="col-xs-12 col-sm-12 col-md-6 how-it-works-step white-txt col">
					<div class="how-it-works-wrap">
						<div class="step step-1" >
							<div class="icon" data-step="1">
								<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewbox="0 0 612.001 612">
						<path d="M604.131 440.17h-19.12V333.237c0-12.512-3.776-24.787-10.78-35.173l-47.92-70.975a62.99 62.99 0 0 0-52.169-27.698h-74.28c-8.734 0-15.737 7.082-15.737 15.738v225.043h-121.65c11.567 9.992 19.514 23.92 21.796 39.658H412.53c4.563-31.238 31.475-55.396 63.972-55.396 32.498 0 59.33 24.158 63.895 55.396h63.735c4.328 0 7.869-3.541 7.869-7.869V448.04c-.001-4.327-3.541-7.87-7.87-7.87zM525.76 312.227h-98.044a7.842 7.842 0 0 1-7.868-7.869v-54.372c0-4.328 3.541-7.869 7.868-7.869h59.724c2.597 0 4.957 1.259 6.452 3.305l38.32 54.451c3.619 5.194-.079 12.354-6.452 12.354zM476.502 440.17c-27.068 0-48.943 21.953-48.943 49.021 0 26.99 21.875 48.943 48.943 48.943 26.989 0 48.943-21.953 48.943-48.943 0-27.066-21.954-49.021-48.943-49.021zm0 73.495c-13.535 0-24.472-11.016-24.472-24.471 0-13.535 10.937-24.473 24.472-24.473 13.533 0 24.472 10.938 24.472 24.473 0 13.455-10.938 24.471-24.472 24.471zM68.434 440.17c-4.328 0-7.869 3.543-7.869 7.869v23.922c0 4.328 3.541 7.869 7.869 7.869h87.971c2.282-15.738 10.229-29.666 21.718-39.658H68.434v-.002zm151.864 0c-26.989 0-48.943 21.953-48.943 49.021 0 26.99 21.954 48.943 48.943 48.943 27.068 0 48.943-21.953 48.943-48.943.001-27.066-21.874-49.021-48.943-49.021zm0 73.495c-13.534 0-24.471-11.016-24.471-24.471 0-13.535 10.937-24.473 24.471-24.473s24.472 10.938 24.472 24.473c0 13.455-10.938 24.471-24.472 24.471zm117.716-363.06h-91.198c4.485 13.298 6.846 27.54 6.846 42.255 0 74.28-60.431 134.711-134.711 134.711-13.535 0-26.675-2.045-39.029-5.744v86.949c0 4.328 3.541 7.869 7.869 7.869h265.96c4.329 0 7.869-3.541 7.869-7.869V174.211c-.001-13.062-10.545-23.606-23.606-23.606zM118.969 73.866C53.264 73.866 0 127.129 0 192.834s53.264 118.969 118.969 118.969 118.97-53.264 118.97-118.969-53.265-118.968-118.97-118.968zm0 210.864c-50.752 0-91.896-41.143-91.896-91.896s41.144-91.896 91.896-91.896c50.753 0 91.896 41.144 91.896 91.896 0 50.753-41.143 91.896-91.896 91.896zm35.097-72.488c-1.014 0-2.052-.131-3.082-.407L112.641 201.5a11.808 11.808 0 0 1-8.729-11.396v-59.015c0-6.516 5.287-11.803 11.803-11.803 6.516 0 11.803 5.287 11.803 11.803v49.971l29.614 7.983c6.294 1.698 10.02 8.177 8.322 14.469-1.421 5.264-6.185 8.73-11.388 8.73z" fill="#FFF" /> </svg>
							</div>
							<h2 style="font-color:#000;background:#fff;padding:18px;border-radius:5px;font-weight:700;">How to order food on train offline from Dibrail? </h2>
							<ul class="pay-inf" style="font-size:16px;color: #fff;text-align:left;margin-left:15%;line-height:1.8"><br>
								<li><i class="fa fa-arrow-right" aria-hidden="true"></i>Call Dibrail at 8263 940 940 </li>
								<li><i class="fa fa-arrow-right" aria-hidden="true"></i>Some of our representatives will help you with placing the order</li>
								<li><i class="fa fa-arrow-right" aria-hidden="true"></i>Mention some important details while ordering food in train: </li>
								<li class="container"><i class="fa fa-arrow-right" aria-hidden="true"></i>The station name where you want to receive the food </li>
								<li class="container"><i class="fa fa-arrow-right" aria-hidden="true"></i> Your choice of food items with the desired quantity </li>
								<li class="container"><i class="fa fa-arrow-right" aria-hidden="true"></i>The passengers’ details </li>
								<li class="container"><i class="fa fa-arrow-right" aria-hidden="true"></i>Your preferred mode of payment – online or Cash on Delivery </li>
								<li><i class="fa fa-arrow-right" aria-hidden="true"></i>Your order will be successfully placed! You can relax in your train seat and enjoy fresh and hot food in train at your seat. </li>
								
							</ul>
							


						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-6 how-it-works-steps white-txt col">
					<div class="how-it-works-wrap">
						<div  style="padding-bottom:30px">
							<div class="containe ">
								<img width="100%"  src="img/dishes/dibrail-dosa.webp" alt="Dibrail" class="dark-log" style="width:85%;" />
							</div>
						</div>
					</div>
				</div>
				
				
			</div>
			
		</div>
	</div>
</div>
<!-- How it works block ends -->

<!-- How it works block starts -->
<div class="how-it-works" style="color:#000;background-color:#EFDEC4;" id="id1">
	<div class="container">
		<div class="text-xs-center" style="word-spacing:1.2px;" >
			

				<div class="col-xs-12 col-sm-12 col-md-12 how-it-works-ste white-txt col">
					<h4 style="color:#000;background:#fff;padding:15px;border-radius:5px;text-align:left;font-weight:700;">Get food on train at your own seat from Dibrail. </h4>
					<ul class="pay-info" style="font-size:16px;color: ;text-align:left;"><br>
						<li>Order from a variety of cuisines and food items from FSSAI-approved restaurants. Order food on trains across 450+ stations from our trusted restaurant partners. Get food delivered to your seat at your desired station.</li>
						<li>You can enjoy fresh and hot meals that are prepared hygienically at your train seat. With Dibrail at your rescue, you can avoid being dependent on stale and unhygienic food provided in the pantry or sold by the vendors at the station or carrying bulky food from home. Choose from a variety of restaurant food in train and enjoy wholesome and delicious food on train. Order your choice of healthy, fresh and tasty food in train at affordable rates. Apply coupons to earn discounts on your online food order in train. You could freely enjoy the most delicious meal at competitive rates.  </li>
						
						
					</ul>
					
				</div>

				<div class="col-xs-12 col-sm-12 col-md-12 how-it-works-ste white-txt col">       
					<h4 style="font-color:#000;background:#fff;padding:15px;border-radius:5px;text-align:left;font-weight:700;">Order food of your choice in train from Dibrail: </h4>
					<ul class="pay-inf" style="font-size:16px;color: ;text-align:left;"><br>
						<li>With Dibrail, you have lots of options to select the food of your choice. If you prefer veg food in train, you can have multitude of vegetarian menu items to enjoy at a discounted price. Huge variety of non-veg food items are also available at your fingertips. </li>
						<li>When you choose Dibrail, the food in your train journey would never be boring or limited in options or unhygienically prepared by unknown vendors. Order best quality Food in train from trusted Restaurant Partners.</li>
						
						
						
					</ul>
				</div>
				
				<div class="col-xs-12 col-sm-12 col-md-12 how-it-works-ste white-txt col">       
					<h4 style="font-color:#000;background:#fff;padding:15px;border-radius:5px;text-align:left;font-weight:700;">How to order food in train from Dibrail? </h4>
					<ul class="pay-inf" style="font-size:16px;color: ;text-align:left;"><br>
						<li>Ordering food in train is simple from Dibrail. 
						Ordering Food in train is simple from Dibrail. You can either choose to order food in train online from our website www.dibrail.com or directly call us on <a href="tel:+918260940940">08263-940-940</a> .</li>
					</ul>
					
					
				</div>

				<div class="col-xs-12 col-sm-12 col-md-12 how-it-works-ste white-txt col">       
					<h4 style="font-color:#000;background:#fff;padding:15px;border-radius:5px;text-align:left;font-weight:700;">Group food order in train: </h4>
					<ul class="pay-inf" style="font-size:16px;color: ;text-align:left;"><br>
						<li>You can also earn discounts on bulk orders of group food in train from Dibrail. Call our representative at <b>08263 940 940</b> to place group food order in train at affordable rates.  </li>
					
					</ul>
					
					<h4 style="font-color:#000;background:#fff;padding:15px;border-radius:5px;text-align:left;font-weight:700;">Get a variety of food delivery on trains from Dibrail: </h4>
					<ul class="pay-inf" style="font-size:16px;color: ;text-align:left;"><br>
						<li><b>Some special and popular varieties of food you can order from restaurant partners of Dibrail: </b> </li>
						<ul><li><a href="#" target="_blank"><b>Thali in train </b></a> :- Vex Deluxe Thali, Veg Maharaja Thali, Veg Standard Thali, Veg Mini Thali, Jain Deluxe Thali, Pure Jain Thali, South Indian Thali, North Indian Thali, Non-Veg Thali, Chicken Tahli, Egg Thali, Fish Special Thali and many more Thali.</li>
						<li>	<a href="/veg-food-in-train" target="_blank"> <b> Veg food in train </b></a>:- Veg Deluxe Thali, Veg Maharaja Thali, Veg Standard Thali, Veg Mini Thali, Veg Pulao, Veg Biryani with Raita, Mix Veg Curry, Aloo Dum, Paneer Butter Masala, Paneer Bhurji, Dal Fry, Dal Makhni, Veg Fried Rice, Hakka Noodles, Chhole Bhature, Jeera Rice, Chana Masala, Shahi Paneer, Kadhai Paneer and many more.</li>

					<li>	<a href="/non-veg-food-in-train" target="_blank"><b>Non-veg food in train </b></a>:- Butter Chicken, Nov Veg Deluxe Thali, Chicken Biryani, Egg Biryani, Mutton Biryani, Chicken Curry, Chicken Thali, Egg Thali, Fish Thali, Tandoori Chicken, Chicken 65, Omelette, Mutton Korma, Tunde Kabab, Chicken Tikka, Fish Fry, Prawns, Egg Curry, Hyderabadi Egg Biryani, and many more.</li>
					<li><a href="/jain-food-in-train" target="_blank"><b>	Jain food in train</b></a>:- Pure Jain Food, Jain Deluxe Thali, Jain Thali, Jain Food, Jain Mini Thali, Jaid Pav Bhaji, Jain Chana Masala, Jain Sada Thali and many more Foods.
					</li>
					<li>	<a href="#" target="_blank"><b>Pizza in train</b></a>:- Margherita Pizza, Quick Tomato Pizza, Four Cheese Pizza, Paneer Pizza, Butter Paneer Pizza, Veg Cheese Pizza, Capsocum Pizza, Capsocum Paneer Pizza, Cheese Pizza, Chilly Tomato Pizza, and many more.
					</li>
					<li>    <a href="/bulk-enquiry" target="_blank"><b>Group food order in train</b></a>:- Group Order more than 20 Veg Standard Thali, 50 Special Veg Thali, 100 Veg Biryani with Raita, Jain Food Order etc.</li>
					<li>	<a href="#" target="_blank"><b>Chinese food in train </b></a>:- Veg Chowmein, Maggi, Veg Spring Roll, Veg Crispy, Gobi Manchurian, Paneer Chilly, Veg Fried Rice, Veg Manchurian, Veg Hakka Noodles, Veg Schezwan Fried Rice, Veg Schezwan Noodles, Paneer 65, Chicken Fried Rice, Egg Fried Rice, Chicken Chilly, Chicken Manchurian and many more.</li>
					<li>	<a href="#" target="_blank"><b>Biryani in train </b></a>:- Veg Biryani with Raita, Chicken Biryani with Raita, Hyderabadi Dum Biryani, Egg Biryani with Raita, Chicken Dum Biryani, Mutton Biryani, Awadhi Biryani, Kolkata Biryani and many more.</li>
					<li>	<a href="#" target="_blank"><b>Fast food in train </b></a>:- Veg Chowmein, Maggi, Veg Spring Roll, Veg Crispy, Gobi Manchurian, Paneer Chilly, Veg Fried Rice, Veg Manchurian, Veg Hakka Noodles, Veg Schezwan Fried Rice, Veg Schezwan Noodles, Paneer 65, Chicken Fried Rice, Egg Fried Rice, Chicken Chilly, Chicken Manchurian and many more.</li>
					<li>    <a href="#" target="_blank"><b>Breakfast in train </b></a>:- Puri Subji, Chhole Puri, Samosa, Cutlet, Chhole Bhature, Poha, Sandwich, French Fries, Boiled Egg, Pav Bhaji, Bread Omelette, Upma, Veg Cutlet, Aloo Paratha, Veg Cutlet, Idli Sambar, Vada Sambhar and many more</li>
					<li>	<a href="#" target="_blank"><b>Lunch in train </b></a>:- Veg Deluxe Thali, Veg Maharaja Thali, Veg Standard Thali, Veg Mini Thali, Veg Pulao, Veg Biryani with Raita  Non-Veg Thali, Chicken Tahli, Egg Thali, Fish Special Thali and many more.</li>
					<li>	<a href="#" target="_blank"><b>Dinner in train Snacks in train </b></a>:- Veg Deluxe Thali, Veg Maharaja Thali, Veg Standard Thali, Veg Mini Thali, Veg Pulao, Veg Biryani with Raita  Non-Veg Thali, Chicken Tahli, Egg Thali, Fish Special Thali and many more.</li>
					<li>	<a href="#" target="_blank"><b>North Indian food in train </b></a>:- Jeera Rice, Aloo Dum, Paneer Butter Masala, Shahi Paneer, Shahi Paneer, Dal Fry, Dal Tadka, Mix Veg, Chana Masala, Tawa Roti, Tandoori Roti, Chapati, Veg Fried, Aloo Gobhi, Veg Pulao and many more.</li>
					<li>	<a href="#" target="_blank"><b>South Indian food in train </b></a> :- Idli Sambhar, Vada Sambhar, Idli Vada Sambhar, Plain Dosa, Masala Dosa, Onion Dosa, Onion Uttapam, Rasm, Poriyal and many more.</li>
					<li>	<a href="#" target="_blank"><b>Cakes in train </b></a>:- Chocolate Cake, Blackforest Cake, Pineapple Cake, Strawberry Pastry, Black Forest Pastry, Chocolate Pastry, Pineapple Pastry and many more.</li>
					<li>	<a href="#" target="_blank"><b>Group food order in train </b></a>:- Group Order more than 20 Veg Standard Thali, 50 Special Veg Thali, 100 Veg Biryani with Raita, Jain Food Order etc. </li>
					<li>	<a href="#" target="_blank"><b>Beverages in train</b></a> including tea, coffee, and cold drinks, etc.</li>
					<li>	<a href="#" target="_blank"><b>Italian food in train </b></a>:- Chilly Pizza, Onion Pizza, Tomato Pizza, Corn Cheese Pizza, Onion Capsocum Pizza, Sweet Corn Tomato Pizza, Sweet Corn Butter Pizza, Chilly Paneer Pizza and many more.</li>
					<li>   <a href="#" target="_blank"><b>Continental food in train </b></a> :-  Margherita Pizza, Quick Tomato Pizza, Four Cheese Pizza, Paneer Pizza, Butter Paneer Pizza, Veg Cheese Pizza,  Veg Chowmein, Maggi, Veg Spring Roll, Veg Crispy, Gobi Manchurian, Paneer Chilly, Veg Fried Rice, Veg Manchurian, Veg Hakka Noodles, Veg Schezwan Fried Rice and many more.</li>
					<li>	<a href="#" target="_blank"><b>Gujarati food in train </b></a> :- Gujarati Thali, Khandvi, Khaman, Khichu, Fafda, Khakha, Ganthiya, Patra, Lilo Chevdo, Gujarati Dal, Undhiyu, Thepla, Rothlo, Juwar Rotla, Nagli Rotla, Aam Ras, Ghooghra, Basundi, Shrikhand, Fada ni Lapsi, Dabeli and many more</li>
					<li>	<a href="#" target="_blank"><b>Rajasthani food in train </b></a>:- Gutte Ki Subzi, Laal Maans, Ker Sangri, Papad Ki Subzi, Bajra Ki Roti with Lasun Chutney, Raab, Onion Kachori, Ghevar, Dal Baati Churma and many more
					</li>

					</ul></ul>
					
					
					<h4 style="color:#000;background:#fff;padding:15px;border-radius:5px;text-align:left;font-weight:700;">Why order food in train from Dibrail?</h4>
					<ul class="pay-info" style="font-size:16px;color: ;text-align:left;"><br>
					<li><b>Dibrail follows the e-catering guidelines and ensures the quality of food is healthy and hygienic</b></li>
					   <ol>	<li>Trusted FSSAI-approved restaurant partners at each station. Every restaurant partner undergoes a stringent quality assurance approval process to deliver the best quality food which is prepared hygienically.</li>
						<li>	Huge variety of food options to choose from for breakfast, lunch, snacks and dinner. All types of veg and non-veg food items to satiate your hunger cravings during the train journey.</li>
						<li>	Presence in 450+ stations and growing to ensure availability of food at multiple stations across India. Wherever you travel, you can easily get food delivered to your train seat at your desired station.</li>
						  <li>  Easy process to place a food order online through the website in simple steps</li>
						 <li>	Option to directly call for placing the food order offline</li>
						<li>	Multiple payment options are available online including net banking, debit card, credit card, UPI or wallets</li>
						<li>	Option to pay Cash on Delivery (COD) after receiving your food at your train seat</li>
						<li>	Earn discounts on your food order by applying coupons and codes</li>
						<li>	Get food delivered directly to your train seat by our delivery executives</li>
						</ol>
					 </li>
					</ul>
				</div>
				
				  
				
				<div class="col-xs-12 col-sm-12 col-md-12 how-it-works-ste white-txt col">       
					<h4 style="font-color:#000;background:#fff;padding:15px;border-radius:5px;text-align:left;font-weight:700;">How to place online food order in train Dibrail? </h4>
					<ul class="pay-inf" style="font-size:16px;color: ;text-align:left;"><br>
						<li><b>Follow these steps for online food order in train from Dibrail:</li></b>
						<ol><li>	Visit the website <b>www.dibrail.com</b></li>
						<li>	Enter the name of the station where you want your food to be delivered</li>
						<li>	Enter PNR and Mobile Number and Click on Submit Button to get Call Back.</li>
						<li>	Select the Restaurant Partner and Add the food items of your choice from the menu.</li>
						<li>	Enter the Journey Details like Passenger Name, Mob, Coach/Seat etc.</li>
						<li>	Make payment through any of the online modes Just Like Debit Card, Credit Cards, Internet Banking, Paytm, Phone Pay, Google Pay or other Wallet UPI Payment or choose to pay Cash on Delivery</li>
						<li>	<b>Sit back and relax!</b> Your order will be delivered to your train seat before the train’s departure</li></ol>

					</ul>
				</div>
				
				<div class="col-xs-12 col-sm-12 col-md-12 how-it-works-ste white-txt col">       
					<h4 style="font-color:#000;background:#fff;padding:15px;border-radius:5px;text-align:left;font-weight:700;">How to order food on train offline from Dibrail? </h4>
					<ul class="pay-inf" style="font-size:16px;color: ;text-align:left;"><br>
						<li><b>If your internet connectivity is poor, you can place your food order in train offline from Dibrail.
Direct Call Dibrail at 08263 940 940 One of our representatives will help you with placing the order Mention some important details while ordering food in train :-</b></li>
					   <ul><li>●The station name where you want to receive the food</li>
						<li>●	Your choice of food items with the desired quantity and any special instructions from your end</li>
						<li>●	The passengers’ details</li>
						<li>●	Your preferred mode of payment – online or Cash on Delivery</li></ul>
							<li>Your order will be successfully placed! You can relax in your train seat and enjoy fresh and hot food in train at your seat.</li></ol>

					</ul>
				</div>
				
				
				<div class="col-xs-12 col-sm-12 col-md-12 how-it-works-ste white-txt col">
					<h4 style="color:#000;background:#fff;padding:15px;border-radius:5px;text-align:left;font-weight:700;">Best food delivery in trains for short and long train journeys: </h4>
					<ul class="pay-info" style="font-size:16px;color: ;text-align:left;"><br>
						<li>Whether you need a one-time meal for a short journey or repeated meals at regular intervals during a long train journey, Dibrail can deliver the food of your choice at the en-route stations. </li>
				
					</ul>
				</div>
				
			

				
			 <div class="col-xs-12 col-sm-12 col-md-12 how-it-works-ste white-txt col">       
					<h4 style="font-color:#000;background:#fff;padding:15px;border-radius:5px;text-align:left;font-weight:700;">Get food delivery in all types of pantry and non-pantry trains: </h4>
					<ul class="pay-inf" style="font-size:16px;color: ;text-align:left;"><br>
						<li>Dibrail delivers food of your choice on all types of trains. If you want food delivery on trains such as Rajdhani Express, Shatabdi Express, or any other trains with or without a pantry car, contact Dibrail <b>(08263 940 940)</b> for timely delivery of the best food at your train seat.  </li>
					
					</ul>
					<h4 style="font-color:#000;background:#fff;padding:15px;border-radius:5px;text-align:left;font-weight:700;">Get online food delivery in train at 450+ stations from Dibrail. </h4>
					<ul class="pay-inf" style="font-size:16px;color: ;text-align:left;"><br>
						<li><b>Order your favourite khana in train online at any of the 450+ stations you’re travelling across during your train journey.   </li></b>
					<b><li>Some of the popular stations where the food on train is frequently ordered include: </li></b>
						<li>Pt. Deen Dayal Upadhaya Jn (DDU), Bhubneshwar (BBS), Visakhapatnam (VSKP), Bilaspur (BSP), Patna (PNBE), Howrah (HWH), Kharagpur (KGP), Prayagraj Jn (PRYJ), Gorakhpur Jn (GKP), Kanpur Central (CNB), Amritsar (ASR), Sultanpur (SLN), Mirzapur (MZP), Lalitpur (LAR), Miraj (MRJ), Jalgaon (JL), Cuttack (CTC), Salem (SA), Hajrat Nizamuddin (HZN), Jaipur (JP), Secunderabad Jn (SC), Varanasi (BSB), Vijaywada (BZA), Madurai Jn (MDU), Bangalore City (SBC), Agra Cantt (AGC), Gwalior (GWL), Bhopal (BPL), Yesvantpur (YPR), Chennai Central (MAS), Chennai Egmore (MS), Thrisur (TCR), Pipariya (PPI), Burhanpur (BAU), Khandwa (KNW), Kazipet Jn (KZT), Itarsi (ET), Malda Town (MLDT), Daund (DD), Delhi Cantt (DEC), Alwar (AWR), Nagpur (NGP), Satna (STA), Rani Kamlapati (RKMP), Pune (PUNE), Surat (ST), Vadodara (BRC), Ahmedabad (ADI), Virangana Laxmibai (VGLB), Bareilly (BE), Tatanagar (TATA), Gaya Jn (GYA), Mau Jn (MAU), Etawah (ETW), Coimbatore Jn (CBE), Rajkot (RJT), Tambaram (TBM), Jaunpur (JNU), Baranki (BBK), Rai-Bareli Jn (RBL), Panvel (PNVL), Navsari (NVS), Barddhaman (BWN), Ghaziabad (GZB), Bathinda Junction (BTI), Balasore (BLS), Saugor (SGO), Moradabad (MB), Ujjain (UJJN), Sonipat (SNP), Rewari (RE), Guntur Jn (GNT), Asansol (ASN), Nasik Road (NK), Manmaad (MMR)
and 450+ more Stations across India.</li>
						

					</ul>
					<h4 style="font-color:#000;background:#fff;padding:15px;border-radius:5px;text-align:left;font-weight:700;">Pay online or Cash on delivery after receiving food delivery on trains: </h4>
					<ul class="pay-inf" style="font-size:16px;color: ;text-align:left;"><br>
						<li>Choose to pay using your preferred mode of payment, either from online options including net banking, debit card, credit card, UPI or Wallets or opt for offline Cash on Delivery (COD) that can be paid after the <a href="https://dibrail.com/food-delivery-in-train" target="_blank"> <b>food delivery in train.</b></a> </li>
					</ul>
					<h4 style="color:#000;background:#fff;padding:15px;border-radius:5px;font-weight:700;text-align:left;">Order best quality food in train from trusted restaurant partners:  </h4>
					<ul class="pay-info" style="font-size:16px;color: ;text-align:left;"><br>
						<li>While choosing one of the restaurant partners for placing the online food order in train, you can check the ratings and reviews of the restaurants and leave feedback on your food order too. In case, you’ve any complaints regarding the food order, the support team will help you out with a quick resolution. </li>
						
						
						
					</ul>
				</div>
			 
			 

		</div>

	</div>
</div>


<div style=" background-color:#EFDEC4" id="id2"><br><br>
<h4 style=" text-underline-offset: 4px;color:#000;text-align:center;font-weight:700"><u>Join Us as Our Partners</u></h4><br>

	<div class="container"  style="padding:30px;">
		<div class="col-xs-12 col-sm-12 col-md-6 img-gap">
			<a href="registration" ><img width="100%"  style="border-radius:10px" src="img/re2.webp" alt="Dibrail"   /></a>
		</div>
		<div class=" col-xs-12 col-sm-12 col-md-6 img-gap">
			<a href="registration" ><img width="100%"  style="border-radius:10px" src="img/to3.webp" alt="Dibrail"  /></a>
		</div>
	</div><br>
</div>


<!-- How it works block starts   background: rgba(255, 255, 255, 1) url(img/px.webp)  no-repeat;  -->
<div style=" background-color:#EFDEC4">
	<div class="container">
		<div class="text-xs-center" style="zoom:70%;padding-top:50px" >
			<h2 style=" text-underline-offset: 4px;color:#000;text-align:center;font-weight:700"><u>Valuable Customer Feedback</u></h2><br>
		   
			<div class="row how-it-works-solution">
				<div class="col-xs-12 col-sm-12 col-md-4 how-it-works-steps white-txt col">
						<div class="testimonial-bg">
							<div id="testimonial-slid" >
								<div class="testimonial" >
									<p class="description">
									   <b>Excellent service by Dibrail.</b>
										I was travelling from Howrah to Vijayawada then I ordered Veg Thali. the delivery was very fast & the packing is so good overall Very good service,
										
									</p>
									
									<h3 class="title">Raushan Kumar Singh</h3>
									<span class="post"></span>
								</div>
							</div>
						</div>
				</div>
				
				 <div class="col-xs-12 col-sm-12 col-md-4 how-it-works-steps white-txt col">
					 <div class="testimonial-bg nomob">
						<div id="testimonial-slide" class="owl-carouse">
							<div class="testimonial">
								<p class="description">
								   <b>Excellent service by Dibrail.</b>
									The delivery was very fast & the packing is so good,
									I request all of you to order food from Dibrail because its service is very good.
								</p>
								
								<h3 class="title">Prateksha Agarwal</h3>
								<span class="post"></span>
							</div>
						</div>
					</div>
				</div>
				
				<div class="col-xs-12 col-sm-12 col-md-4 how-it-works-steps white-txt col">
					 <div class="testimonial-bg nomob">
						<div id="testimonial-slide" class="owl-carouse">
							<div class="testimonial">
								<p class="description">
								   <b>Excellent service by Dibrail.</b>
									The delivery was very fast & the packing is so good,
									I request all of you to order food from Dibrail because its service is very good.
								</p>
								
								<h3 class="title">Ayushi Khanna</h3>
								<span class="post"></span>
							</div>
						</div>
					</div>
				</div>	
			</div>
		</div>
		<!-- 3 block sections ends -->
		
	</div><br>
</div>

<!--
<div class="floating_btn">
	<a target="_blank" href="tel:+918263940940">
	  <div class="contact_icon">
		<i class="fa fa-phone my-float"></i>
	  </div>
	</a>
	<p class="text_icon">Order On Call !</p>
</div>
Google Tag Manager (noscript) -->


<div class="floating_btn2">
	<a aria-label="Chat on WhatsApp" target="_blank" href="https://wa.me/919060078551?text=I want to Food Order in Train (मैं ट्रेन में खाना ऑर्डर करना चाहता हूँ I)
">
	  <div class="contact_icon2">
		<i class="fa fa-whatsapp my-float2"></i>
	  </div>
	</a>
	<p class="text_icon">Order On Whatsapp</p>
</div>

<div class="v-item-group">
	<div class="v-bottom-navigation d-flex d-sm-none v-item-group theme--light v-bottom-navigation--fixed" style="height: 56px; transform: none;">

	  <a href="dishes#foodCart" class="mobileFooterMenu v-btn v-btn--is-elevated v-btn--has-bg v-btn--router theme--light v-size--default">
		<span class="v-btn__content">
		  <span class="red--text">Home</span>
		  <i aria-hidden="true" class="fa fa-home"></i>
		</span>
	  </a>
	  <a href="track_order" class="mobileFooterMenu v-btn v-btn--is-elevated v-btn--has-bg v-btn--router theme--light v-size--default">
		<span class="v-btn__content">
		  <span class="red--text">Track</span>
		  <img src="img/track_order.png" width="" height="30" />
		</span>
	  </a>

	  <a href="offers" class="mobileFooterMenu v-btn v-btn--is-elevated v-btn--has-bg v-btn--router theme--light v-size--default">
		<span class="v-btn__content">
		  <span class="red--text">Offers</span>
		  <i aria-hidden="true" class="fa fa-gift"></i>
		</span>
	  </a>

	  <a href="tel:+918263940940" class="mobileFooterMenu v-btn v-btn--is-elevated v-btn--has-bg v-btn--router theme--light v-size--default">
		<span class="v-btn__content">
		  <span class="red--text">Order</span>
		  <div class="contact_icon">
			<i class="fa fa-phone my-float" style="font-size:20px"></i>
		  </div>
		</span>
	  </a>
	  <a href="all-stations" class="mobileFooterMenu v-btn v-btn--is-elevated v-btn--has-bg v-btn--router theme--light v-size--default">
		<span class="v-btn__content">
		  <span class="red--text">Food-Menu</span>
		  <i class="fa fa-th-large"></i>
		</span>
	  </a>
	  
	  
	</div>
</div>
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P4NWD6Q"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<script>
$(document).ready(function(){
    $('.menu-toggle').click(function(){
      $('nav').toggleClass('active');
    })
  })
</script>	
<?php 
//require_once("inc/contact.inc.php");
include("footer.php");

?>